using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDeath : MonoBehaviour
{

    private void OnCollisionEnter2D(Collision2D collision)   // Funkce od Unity, kter� se za�ne volat pokud se t�leso za�ne dot�kat jin�ho koliduj�c�ho t�lesa
    {
        if (collision.collider.CompareTag("Obstacle")) // Pokud hr�� bude kolidovat s jin�m objektem ze hry kter� m� tag "Obstacle"
        {
            Die();
        }
    } 

    void Die()
    {

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);   // Na�te sc�nu od znova
    }
}
