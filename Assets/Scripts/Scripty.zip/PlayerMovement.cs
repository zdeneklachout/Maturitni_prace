using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb;   // Rigidbody2D je t��da v Unity, d�ky kter� mohu snadno ovl�dat fyziku ve 2D
    public float speed = 5f;  

    public float jumpForce = 15f;
    private bool isGrounded = false;

    public float rotationSpeed = 360f;
    private float targetAngle = 0f;
    private bool isRotating = false;

    void Start()    // Funkce od Unity kter� se vol� pouze jednou p�i spu�t�n� programu
    {
        rb = GetComponent<Rigidbody2D>();    // Z�sk�m konkr�tn� Rigidbody2D kter� je v Unity p�ipojeno k hr��ovi
    }
    void Update()   // Funkce od Unity kter� se vol� ka�d� sn�mek
    {
        rb.linearVelocityX = speed;    // Nastaven� hr��ovo rychlosti ve sm�ru X na speed
        
        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)) && isGrounded)   // Pokud hr�� stiskne mezern�k nebo lev� tla��tko my�i
        {
            Jump();
            StartRotation();

        }

        if (isRotating)
        {
            transform.Rotate(0f, 0f, -rotationSpeed * Time.deltaTime);  // D�ky transform odkazuji na pozici, rotaci a velikost hr��e a pomoc� funkce Rotate ��k�m:
                                                                        // rotuj na ose Z o -rotationSpeed za sekundu
                                                                        // znam�nko - mi ur�uje sm�r rotace doprava

            // D�ky Mathf.DeltaAngle zjist� rozd�l mezi dv�ma �hly:
            // st�vaj�c� �hel(transform.eulerAngles.z -> naklon�n� hr��e na ose z) a c�lovej targetAngle
            // pokud je rozd�l v absolutn� hodnot� men�� ne� 2, �hel se automaticky nastav� na ten po�adovan�
            if (Mathf.Abs(Mathf.DeltaAngle(transform.eulerAngles.z, targetAngle)) < 2f)   
            {
                transform.rotation = Quaternion.Euler(0, 0, targetAngle);   // Pomoc� Quaternion.Euler vytvo��me rotaci z c�lov�ho �hlu (Unity ukl�d� rotaci jako quaternion,
                                                                            // d�ky funkci Euler mohu rotaci napsat ve t�ech sou�adn�ch x,y,z)
                isRotating = false;
                
            }
        } 

    }

    void Jump()
    {
        rb.linearVelocityY = jumpForce;   // Nastaven� hr��ovo rychlosti ve sm�ru Y na jumpForce
        isGrounded = false;
    }

    void StartRotation()
    {
        targetAngle -= 180f; // Znam�nko m�nus u�uje sm�r rotace doprava
        isRotating = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)    // Funkce od Unity, kter� se za�ne volat pokud se t�leso za�ne dot�kat jin�ho koliduj�c�ho t�lesa
    {
        if (collision.gameObject.CompareTag("Ground"))   // Pokud hr�� bude kolidovat s jin�m objektem ze hry kter� m� tag "Ground"
        {
            isGrounded = true;
        }
    }
}
