using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public Transform player;   // Odkaz na komponentu transform jin�ho objektu(hr��e), d�ky n� m�m p��stup k pozici, rotaci a velikosti hr��e
    public float offsetX = 2f;

    private float fixedY;

    private void Start()
    {
        fixedY = transform.position.y;  // Ulo�en� pozice y kamery do prom�nn�
    }

    void LateUpdate()  // Funkce od Unity stejn� jako Update akor�t se vol� po v�ech Update funkc�ch, funkce Update se vol� ka�d� sn�mek od za��tku programu
    {
        transform.position = new Vector3(player.transform.position.x + offsetX, fixedY, transform.position.z);  // Nastven� pozice kamery,
                                                                                                                // na ose x tak aby n�sledovala hr��e s odstupem,
                                                                                                                // na ose y aby m�la hodnotu fixedY, 
                                                                                                                // osu z jsem nechal b�t tak jak je
    }
}
